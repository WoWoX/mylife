package com.smartfoxserver.redbox.utils;

import java.io.File;
import java.io.FilenameFilter;
import java.util.LinkedList;

public class FileFilter implements FilenameFilter
{
	private String zoneName;
	private LinkedList<String> fileExtensions;
	
	public FileFilter(String zone, LinkedList<String> fileExt)
	{
		zoneName = zone;
		fileExtensions = fileExt;
	}
	
	public boolean accept(File dir, String filename)
	{
		int zoneSepIndex = filename.indexOf("_");
		int extSepIndex = filename.lastIndexOf(".");
		
		if (zoneSepIndex > 0 && extSepIndex > zoneSepIndex && extSepIndex < filename.length())
		{
			// Check zone name and file extension
			if (filename.substring(0, zoneSepIndex).equals(zoneName) && fileExtensions.contains(filename.substring(extSepIndex + 1)))
				return true;
		}
		
		return false;
	}
}

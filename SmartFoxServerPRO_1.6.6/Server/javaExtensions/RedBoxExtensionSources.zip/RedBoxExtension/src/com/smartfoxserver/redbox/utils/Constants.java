package com.smartfoxserver.redbox.utils;

/**
 * RedBox constants.
 * 
 * @version	1.0.0
 * 
 * @author	The gotoAndPlay() Team
 * 			http://www.smartfoxserver.com
 * 			http://www.gotoandplay.it
 */
public class Constants
{
	public static final String AV_CHAT_MANAGER_KEY = "chat";
	public static final String AV_CLIP_MANAGER_KEY = "clip";
	
	public static final String EXTENSION_KEY = "$RB";
	public static final String DEFAULT_LASTMODIFIED_FORMAT = "dd/MM/yyyy HH:mm:ss";
	
	public static final String CONFIG_FILE = "redbox.properties";
	public static final String CONFIG_RED5_ROOT = "red5Path";
	public static final String CONFIG_LASTMODIFIED_FORMAT = "lastModifiedFormat";
}

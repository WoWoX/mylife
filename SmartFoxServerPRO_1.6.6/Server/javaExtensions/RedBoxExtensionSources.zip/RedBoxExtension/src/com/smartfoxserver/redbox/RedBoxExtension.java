package com.smartfoxserver.redbox;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Properties;

import org.json.JSONObject;

import com.smartfoxserver.redbox.managers.AVChatManager;
import com.smartfoxserver.redbox.managers.AVClipManager;
import com.smartfoxserver.redbox.managers.IRequestHandler;
import com.smartfoxserver.redbox.utils.Constants;
import com.smartfoxserver.redbox.utils.Logger;

import it.gotoandplay.smartfoxserver.SmartFoxServer;
import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.data.Zone;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;
import it.gotoandplay.smartfoxserver.extensions.AbstractExtension;
import it.gotoandplay.smartfoxserver.extensions.ExtensionHelper;
import it.gotoandplay.smartfoxserver.lib.ActionscriptObject;


/**
 * SmartFoxServer's RedBox extension.
 * This class is responsible for dispatching requests to sub-handlers, like the AVClipManager or the AVChatManager.
 * 
 * @version	1.0.0
 * 
 * @author	The gotoAndPlay() Team
 * 			http://www.smartfoxserver.com
 * 			http://www.gotoandplay.it
 */
public class RedBoxExtension extends AbstractExtension
{
	//--------------------------------------
	// CLASS CONSTANTS
	//--------------------------------------
	
	private static int MINIMUM_VERSION = 162;
	
	//--------------------------------------
	//  PRIVATE VARIABLES
	//--------------------------------------
	
	@SuppressWarnings("unused")
	private ExtensionHelper helper;
	private HashMap<String, IRequestHandler> managers = new HashMap<String, IRequestHandler>();	// HashMap containing the available managers
	private Properties redBoxConfig;
	
	//-------------------------------------------------------
	// PUBLIC METHODS
	//-------------------------------------------------------
	
	public void init()
	{
		helper = ExtensionHelper.instance();
		
		// Load RedBox external configuration
		loadConfig();
		
		if (redBoxConfig != null)
		{
			// Enable logging
			Logger.enableLogging = (redBoxConfig.getProperty("log").equals("1"));
			
			// Create requests managers (check minimum SmartFoxServer version)
			String version = SmartFoxServer.getInstance().getVersion();
			String[] s = version.split("\\.");
			int ver = Integer.parseInt(s[0] + s[1] + s[2]);
			
			if (ver >= MINIMUM_VERSION)
			{
				managers.put(Constants.AV_CHAT_MANAGER_KEY, new AVChatManager(this));
				managers.put(Constants.AV_CLIP_MANAGER_KEY, new AVClipManager(this));
			}
			else
				Logger.logWarning("Extension error: minimum required SmartFoxServer version is 1.6.2");
			
			Logger.logInfo("Extension initialized");
		}
	}
	
	public void destroy()
	{
		
	}
	
	public String getConfigParam(String name)
	{
		return redBoxConfig.getProperty(name);
	}
	
	public Zone getCurrentZone()
	{
		return helper.getZone(getOwnerZone());
	}
	
	public User getUserById(int userId)
	{
		return helper.getUserById(userId);
	}
	
	@SuppressWarnings("unchecked")
	public LinkedList getUserChannel(User u)
	{
		LinkedList ll = new LinkedList();
		ll.add(u.getChannel());
		
		return ll;
	}

	public void handleRequest(String cmd, JSONObject data, User fromUser, int fromRoom)
	{
		Logger.logInfo("Request received: " + cmd);
		
		// Retrieve the recipient manager from the command string
		String[] cmdArray = cmd.split(":");
		String managerKey = cmdArray[0];
		String commandKey = cmdArray[1];
		
		// Grab manager from the managers map
		IRequestHandler manager = managers.get(managerKey);
		
		// If manager exists, process request
		if (manager != null)
		{
			try
			{
				// Dispatch request to manager
				manager.handleRequest(commandKey, data, fromUser);
			}
			catch(Exception e)
			{
				// Log error
				Logger.logWarning(e.getMessage());
				e.printStackTrace();
			}
		}
		else
		{
			Logger.logWarning("Unrecognized request handler: " + managerKey);
		}
	}

	public void handleInternalEvent(InternalEventObject evt)
	{
		String evtName = evt.getEventName();
		Logger.logInfo("Internal event received: " + evtName);
		
		for (Iterator i = managers.entrySet().iterator(); i.hasNext();)
		{ 
		    Map.Entry entry = (Map.Entry)i.next();
		    IRequestHandler manager = (IRequestHandler)entry.getValue();
		    
		    try
			{
		    	// Dispatch request to manager
		    	manager.handleInternalEvent(evt);
			}
			catch(Exception e)
			{
				// Log error
				Logger.logWarning(e.getMessage());
				e.printStackTrace();
			}
		}
	}

	public void handleRequest(String cmd, ActionscriptObject ao, User u, int fromRoom)
	{
		
	}

	public void handleRequest(String cmd, String[] params, User u, int fromRoom)
	{
		
	}
	
	//-------------------------------------------------------
	// PRIVATE METHODS
	//-------------------------------------------------------
	
	/**
	 * Load external configuration file.
	 */
	private void loadConfig()
	{
		redBoxConfig = new Properties();
		
		try
		{
			redBoxConfig.load(new FileInputStream(Constants.CONFIG_FILE));
		}
		catch (IOException error)
		{
			Logger.logWarning("'" + Constants.CONFIG_FILE + "' file not found");
		}
	}
}

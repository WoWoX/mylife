package com.smartfoxserver.redbox.data;

public class ChatSession
{
	public String id;
	public String type;
	public boolean pending;
	
	public boolean enableCam;
	public boolean enableMic;
	
	public int requesterId;
	public String requesterName;
	public String requesterStreamId;
	
	public int recipientId;
	public String recipientName;
	public String recipientStreamId;
	
	public ChatSession()
	{
		
	}
}
package com.smartfoxserver.redbox.managers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Properties;
import java.util.concurrent.ConcurrentHashMap;

import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;

import org.json.JSONException;
import org.json.JSONObject;

import com.smartfoxserver.redbox.RedBoxExtension;
import com.smartfoxserver.redbox.data.Clip;
import com.smartfoxserver.redbox.utils.Constants;
import com.smartfoxserver.redbox.utils.FileFilter;
import com.smartfoxserver.redbox.utils.Logger;

/**
 * SmartFoxServer's RedBox Audio/Video Clip Manager.
 * This class is responsible for audio/video clips retrieval and handling.
 * 
 * @version	1.0.0
 * 
 * @author	The gotoAndPlay() Team
 * 			http://www.smartfoxserver.com
 * 			http://www.gotoandplay.it
 */
public class AVClipManager implements IRequestHandler
{
	//--------------------------------------
	// CLASS CONSTANTS
	//--------------------------------------
	
	private static final String RED5_STREAMS_PATH = "webapps/SFS_RedBox/streams/";
	private static final String FILE_EXT_FLV = "flv";
	private static final String FILE_EXT_PROP = "prop";
	private static final String FILE_EXT_META = "meta";
	private static final String CLIP_PROP_USERNAME = "username";
	private static final String CLIP_TIMESTAMP = "yyyyMMddHHmmssSSS";
	private static final String CLIP_PROP_HEADER = "Created by SmartFoxServer's RedBox Extension";
	
	// Incoming commands
	private static final String CMD_LIST = "list";
	private static final String CMD_REMOVE = "rmv";
	private static final String CMD_NEW_ID = "newId";
	private static final String CMD_CANCEL = "cancel";
	private static final String CMD_SUBMIT_REC = "sbtRec";
	private static final String CMD_SUBMIT_UPL = "sbtUpl";
	private static final String CMD_DELETE = "del";
	private static final String CMD_UPDATE = "upd";
	
	// Outgoing responses
	private static final String RES_LIST = "list";
	private static final String RES_NEW_ID = "newId";
	private static final String RES_ADD = "add";
	private static final String RES_DELETE = "del";
	private static final String RES_UPDATE = "upd";
	
	// Outgoing errors
	private static final String ERR_SUBMIT = "err_submit";
	
	// Error messages
	private static final String ERRTXT_CLIP_ALREADY_EXISTS = " clip is already in the clips list";
	private static final String ERRTXT_INVALID_CLIP_ID = "Invalid clip ID: ";
	private static final String ERRTXT_FILE_NOT_FOUND = "File not found for clip ID: ";
	private static final String ERRTXT_SAVE_PROPS = "An error occurred while saving clip properties: ";
	
	//--------------------------------------
	//  PRIVATE VARIABLES
	//--------------------------------------
	
	private RedBoxExtension mainExtension;
	private String red5RootPath;
	private String red5StreamsPath;
	private ConcurrentHashMap<String, Clip> clipList;
	private LinkedList<String> notifyList;	// Only users who requested the clips list are then notified of any updates that may occurr
	private HashMap<String, String> tempClips;
	
	//-------------------------------------------------------
	// CONSTRUCTOR
	//-------------------------------------------------------
	
	/**
	 * The AVClipManager contructor.
	 */
	public AVClipManager(RedBoxExtension ext)
	{
		// Initialize AVClipManager
		mainExtension = ext;
		
		// Initialize notification list
		notifyList = new LinkedList<String>();
		
		// Initialize temporary clips list
		tempClips = new HashMap<String, String>();
		
		// Initialize clips list
		initializeClipList();
		
		Logger.logInfo("RedBox's AVClipManager initialized and a/v clips list created (" + clipList.size() + " clips found)");
	}
	
	//-------------------------------------------------------
	// PUBLIC METHODS
	//-------------------------------------------------------
	
	/**
	 * Handle client requests.
	 */
	public void handleRequest(String cmd, JSONObject data, User fromUser) throws Exception
	{
		// Clips list requested
		if (cmd.equals(CMD_LIST))
			handleClipListRequest(fromUser);
		
		// Remove user from notification list
		else if (cmd.equals(CMD_REMOVE))
			handleRemoveUserRequest(fromUser);
		
		// New clip id requested
		else if (cmd.equals(CMD_NEW_ID))
			handleClipIdRequest(fromUser);
		
		// Remove temporary clip
		else if (cmd.equals(CMD_CANCEL))
			handleRecCancelRequest(fromUser);
		
		// Recorded clip submitted
		else if (cmd.equals(CMD_SUBMIT_REC))
			handleRecClipSubmitRequest(fromUser, data);
		
		// Uploaded clip submitted
		else if (cmd.equals(CMD_SUBMIT_UPL))
			handleUplClipSubmitRequest(fromUser, data);
		
		// Delete clip
		else if (cmd.equals(CMD_DELETE))
			handleDeleteClipRequest(fromUser, data);
		
		// Update clip properties
		else if (cmd.equals(CMD_UPDATE))
			handleUpdateClipRequest(fromUser, data);
	}
	
	/**
	 * Handle internal events.
	 */
	public void handleInternalEvent(InternalEventObject evt) throws Exception
	{
		String evtName = evt.getEventName();
		
		// User disconnected or logged out
		if (evtName.equals(InternalEventObject.EVENT_USER_LOST) || evtName.equals(InternalEventObject.EVENT_LOGOUT))
			handleRemoveUserRequest((User) evt.getObject("user"));
	}
	
	//-------------------------------------------------------
	// PRIVATE METHODS
	//-------------------------------------------------------
	
	// Request handlers -------------------------------------
	
	/**
	 * Send clips list to requester.
	 */
	private void handleClipListRequest(User recipient)
	{
		// Add user to notification list
		synchronized (notifyList)
		{
			if (!notifyList.contains(recipient.getName()))
				notifyList.add(recipient.getName());
		}
		
		// Convert clips list to JSON
		net.sf.json.JSONObject jsonClipList =  net.sf.json.JSONObject.fromObject(clipList);
		
		// Send response to recipient
		sendResponse(mainExtension.getUserChannel(recipient), RES_LIST, jsonClipList);
		
		Logger.logInfo("Clips list requested by user " + recipient.getName() + "; user added to clip update notification list");
	}
	
	/**
	 * Remove user from notification list and delete possible temporary clips.
	 */
	private void handleRemoveUserRequest(User user)
	{
		// Remove user from notification list
		synchronized (notifyList)
		{
			if (notifyList.contains(user.getName()))
			{
				notifyList.remove(user.getName());
				
				Logger.logInfo("User " + user.getName() + " removed from clip update notification list");
			}
		}
		
		// Delete temporary clip if existing
		handleRecCancelRequest(user);
	}
	
	/**
	 * Generate a new (unique) clip id and send to requester.
	 */
	private void handleClipIdRequest(User user)
	{
		// Generate new clip id
		String zone = mainExtension.getOwnerZone();
		SimpleDateFormat dateFormatter = new SimpleDateFormat(CLIP_TIMESTAMP);
		String timeStamp = dateFormatter.format(new Date());
		String userId = String.valueOf(user.getUserId());
			
		String clipId = zone + "_" + timeStamp + "_" + userId;
		
		// Add new id to the list of temporary clips
		synchronized (tempClips)
		{
			tempClips.put(user.getName(), clipId);
		}
		
		// Return id to the requester
		net.sf.json.JSONObject params = new net.sf.json.JSONObject();
		params.put("id", clipId);
		
		sendResponse(mainExtension.getUserChannel(user), RES_NEW_ID, params);
		
		Logger.logInfo("New temporary clip id generated for user " + user.getName());
	}
	
	/**
	 * Remove the temporary clip created by the requester.
	 */
	private void handleRecCancelRequest(User user)
	{
		String tempClipId = null;
		
		// Remove user from temporary clips list
		synchronized (tempClips)
		{
			tempClipId = tempClips.remove(user.getName());
		}
		
		if (tempClipId != null)
		{
			deleteClip(tempClipId);
			
			Logger.logInfo("Temporary clip removed for user " + user.getName() + ": " + tempClipId);
		}
	}
	
	/**
	 * Recorded clip submitted: save prop file and update clip list.
	 */
	private void handleRecClipSubmitRequest(User user, JSONObject data)
	{
		Logger.logInfo("Recorded clip submitted by user " + user.getName());
		
		String clipId = null;
		
		// Remove temporary clip id
		synchronized (tempClips)
		{
			clipId = tempClips.remove(user.getName());
		}
		
		// Save clip properties and update clips list
		if (clipId != null)
			addSubmittedClipToList(user, clipId, data);
	}
	
	/**
	 * Uploaded clip submitted: save prop file and update clip list.
	 */
	private void handleUplClipSubmitRequest(User user, JSONObject data)
	{
		Logger.logInfo("Uploaded clip submitted by user " + user.getName());
		
		try
		{
			String clipId = data.getString("id");
			String error = "";
			
			// Validate clip id:
			// 1. Check id clip is already in clip list (to avoid malicious users overwrite clip properties)
			if (clipList.get(clipId) != null)
				error = clipId + ERRTXT_CLIP_ALREADY_EXISTS;
			else
			{
				// 2. check if id begins with zone name
				if (!clipId.split("_")[0].equals(mainExtension.getOwnerZone()))
					error = ERRTXT_INVALID_CLIP_ID + clipId;
				else
				{
					// 3. check if flv file exists
					String flvFilename = clipId + "." + FILE_EXT_FLV;
					File flvFile = new File(red5StreamsPath + flvFilename);
					
					if (!flvFile.exists())
						error = ERRTXT_FILE_NOT_FOUND + clipId;
				}
			}
				
			if (error.equals(""))
			{
				// Save clip properties and update clips list
				addSubmittedClipToList(user, clipId, data);
			}
			else
			{
				// Send error to client
				net.sf.json.JSONObject params = new net.sf.json.JSONObject();
				params.put("err", error);
				sendResponse(mainExtension.getUserChannel(user), ERR_SUBMIT, params);
				
				Logger.logWarning("Invalid clip submitted - " + error);
			}
		}
		catch (JSONException e)
		{
			Logger.logWarning("JSON exception in handleUplClipSubmitRequest method: " + e.getMessage());
		}
	}
	
	/**
	 * Delete a clip and update clip list.
	 */
	private void handleDeleteClipRequest(User user, JSONObject data)
	{
		try
		{
			String clipId = data.getString("id");
			Clip clip = clipList.get(clipId);
			
			// Check if requester is the clip's owner
			if (clip != null && clip.username.equals(user.getName()))
			{
				// Remove clip form clips list
				clipList.remove(clipId);
				
				// Delete clip
				deleteClip(clipId);
				
				// Send clip list update to all clients
				net.sf.json.JSONObject params = new net.sf.json.JSONObject();
				params.put("id", clipId);
				
				sendResponse(getUsersChannels(notifyList, null), RES_DELETE, params);
			}
		}
		catch (JSONException e)
		{
			Logger.logWarning("JSON exception in handleDeleteClipRequest method: " + e.getMessage());
		}
	}
	
	/**
	 * Update clip properties.
	 */
	private void handleUpdateClipRequest(User user, JSONObject data)
	{
		try
		{
			String clipId = data.getString("id");
			Clip clip = clipList.get(clipId);
			
			// Check if requester is the clip's owner
			if (clip != null && clip.username.equals(user.getName()))
			{
				updateClipProperties(user, clipId, data);
			}
		}
		catch (JSONException e)
		{
			Logger.logWarning("JSON exception in handleUpdateClipRequest method: " + e.getMessage());
		}
	}
	
	// Other private methods --------------------------------
	
	/**
	 * Retrieve clips list from filesystem at RedBox extension startup.
	 */
	private void initializeClipList()
	{
		// Create clips list
		clipList = new ConcurrentHashMap<String, Clip>();
		
		// Retrieve Red5 root folder path from external configuation
		red5RootPath = mainExtension.getConfigParam(Constants.CONFIG_RED5_ROOT);
		
		if (!red5RootPath.substring(red5RootPath.length() - 1).equals("/"))
			red5RootPath = red5RootPath.concat("/");
		
		// Build streams folder path
		red5StreamsPath = red5RootPath + RED5_STREAMS_PATH;
		
		// Get zone name for filtering purposes
		String zone = mainExtension.getOwnerZone();
		
		// Create filenames filter
		LinkedList<String> fileExtensions = new LinkedList<String>();
		fileExtensions.add(FILE_EXT_FLV);
		FileFilter flvFilter = new FileFilter(zone, fileExtensions);
		
		// Retrieve files list is Red5 streams folder
		File files = new File(red5StreamsPath);
		
		for (String flvFilename : files.list(flvFilter))
		{
			// Retrieve clip id (--> filename without extension)
			String clipId = flvFilename.substring(0, flvFilename.lastIndexOf("."));
			
			// Build properties filename
			String propFilename = flvFilename + "." + FILE_EXT_PROP;
			
			// Check if the flv file has a ".prop" counterpart
			// If yes, add the flv file to the available clips list
			// If no, the file is probably an orphan of a previous session
			File propFile = new File(red5StreamsPath + propFilename);
			
			if (propFile.exists())
			{
				// Retrieve clip properties
				Properties clipProperties = new Properties();
				
				try
				{
					clipProperties.load(new FileInputStream(propFile));
				}
				catch (IOException error)
				{
					Logger.logWarning("Error reading '" + propFilename + "' file");
					break;
				}
				
				// Create new clip
				Clip clip = createClip(clipId, clipProperties);
				
				// Add clip to clips list
				clipList.put(clipId, clip);
			}
			else
				Logger.logInfo("Orphan clip detected: " + flvFilename);
		}
	}
	
	/**
	 * Save clip properties and update clips list
	 */
	private void addSubmittedClipToList(User submitter, String clipId, JSONObject properties)
	{
		Properties clipProperties = null;
		
		// Save clip properties
		try
		{
			// Build clip filename
			String flvFilename = clipId + "." + FILE_EXT_FLV;
			
			// Build properties filename
			String propFilename = flvFilename + "." + FILE_EXT_PROP;
			
			// Set properties
			clipProperties = new Properties();
			clipProperties.putAll(properties.getJSONObject("properties").getData());
			
			// Add default "username" property
			clipProperties.put(CLIP_PROP_USERNAME, submitter.getName());
			
			// Save properties
			File propFile = new File(red5StreamsPath + propFilename);
			FileOutputStream out = new FileOutputStream(propFile);
			clipProperties.store(out, CLIP_PROP_HEADER);
			out.close();
		}
		catch (Exception e)
		{
			Logger.logWarning("An exception occurred while storing clip properties: " + e.getMessage());
			
			// Delete temporary clip
			deleteClip(clipId);
			
			// Send error to client
			net.sf.json.JSONObject params = new net.sf.json.JSONObject();
			params.put("err", ERRTXT_SAVE_PROPS + e.getMessage());
			sendResponse(mainExtension.getUserChannel(submitter), ERR_SUBMIT, params);
			
			return;
		}
		
		Logger.logInfo("Properties file saved for clip " + clipId);
		
		// Create clip object
		Clip clip = createClip(clipId, clipProperties);
		
		// Add clip to clips list
		clipList.put(clipId, clip);
		
		// Send clip list update to all clients
		net.sf.json.JSONObject params = new net.sf.json.JSONObject();
		params.put("id", clipId);
		params.put("data", clip);
		
		sendResponse(getUsersChannels(notifyList, null), RES_ADD, params);
	}
	
	/**
	 * Create a Clip class instance
	 */
	private Clip createClip(String clipId, Properties clipProperties)
	{
		String flvFilename = clipId + "." + FILE_EXT_FLV;
		File flvFile = new File(red5StreamsPath + flvFilename);
		
		// Create new Clip
		Clip clip = new Clip();
		clip.id = clipId;
		clip.filename = flvFilename;
		clip.setSize(flvFile.length());
		
		Date date = new Date(flvFile.lastModified());
		String dateFormat = mainExtension.getConfigParam(Constants.CONFIG_LASTMODIFIED_FORMAT);
		if (dateFormat == null)
			dateFormat = Constants.DEFAULT_LASTMODIFIED_FORMAT;
		SimpleDateFormat dateFormatter = new SimpleDateFormat(dateFormat);
		
		clip.setLastModified(dateFormatter.format(date));
		
		// Add properties to clip (username property is also referenced directly in the Clip's username property in order to be easily accessible)
		if (clipProperties != null)
		{
			clip.username = clipProperties.getProperty(CLIP_PROP_USERNAME);
			clip.setProperties(clipProperties);
		}
		
		return clip;
	}
	
	/**
	 * Delete clip files (flv, prop, meta)
	 */
	private void deleteClip(String clipId)
	{
		// Check if flv file exists on file system
		String flvFilename = clipId + "." + FILE_EXT_FLV;
		File flvFile = new File(red5StreamsPath + flvFilename);
		
		if (flvFile.exists())
		{
			// Delete file
			try
			{
				flvFile.delete();
				
				Logger.logInfo("FLV file deleted: " + flvFilename);
			}
			catch (SecurityException exc)
			{
				Logger.logWarning(exc.getMessage());
			}
		}
		
		// Check if prop file exists on file system
		String propFilename = flvFilename + "." + FILE_EXT_PROP;
		File propFile = new File(red5StreamsPath + propFilename);
		
		if (propFile.exists())
		{
			// Delete file
			try
			{
				propFile.delete();
				
				Logger.logInfo("PROP file deleted: " + propFilename);
			}
			catch (SecurityException exc)
			{
				Logger.logWarning(exc.getMessage());
			}
		}
		
		// Check if meta file exists on file system (meta file is created by Red5 on first playback)
		String metaFilename = flvFilename + "." + FILE_EXT_META;
		File metaFile = new File(red5StreamsPath + metaFilename);
		
		if (metaFile.exists())
		{
			// Delete file
			try
			{
				metaFile.delete();
				
				Logger.logInfo("META file deleted: " + metaFilename);
			}
			catch (SecurityException exc)
			{
				Logger.logWarning(exc.getMessage());
			}
		}
	}
	
	/**
	 * Update clip properties and update clips list
	 */
	private void updateClipProperties(User requester, String clipId, JSONObject properties)
	{
		Properties clipProperties = null;
		
		// Save clip properties
		try
		{
			// Build clip filename
			String flvFilename = clipId + "." + FILE_EXT_FLV;
			
			// Build properties filename
			String propFilename = flvFilename + "." + FILE_EXT_PROP;
			
			// Set properties
			clipProperties = new Properties();
			clipProperties.putAll(properties.getJSONObject("properties").getData());
			
			// Add default "username" property
			clipProperties.put(CLIP_PROP_USERNAME, requester.getName());
			
			// Save properties
			File propFile = new File(red5StreamsPath + propFilename);
			FileOutputStream out = new FileOutputStream(propFile);
			clipProperties.store(out, CLIP_PROP_HEADER);
			out.close();
		}
		catch (Exception e)
		{
			Logger.logWarning("An exception occurred while storing clip properties: " + e.getMessage());
			
			return;
		}
		
		Logger.logInfo("Properties file saved for clip " + clipId);
		
		// Get clip instance
		Clip clip = clipList.get(clipId);
		
		// Update properties
		clip.setProperties(clipProperties);
		
		// Send clip list update to all clients
		net.sf.json.JSONObject params = new net.sf.json.JSONObject();
		params.put("id", clipId);
		params.put("data", clip);
		
		sendResponse(getUsersChannels(notifyList, null), RES_UPDATE, params);
	}
	
	/**
	 * Send response to client/s.
	 */
	private void sendResponse(LinkedList recipients, String responseKey, net.sf.json.JSONObject params)
	{
		if (params == null)
			params = new net.sf.json.JSONObject();
		
		// Build response name and add to params
		String res = Constants.EXTENSION_KEY + ":" + Constants.AV_CLIP_MANAGER_KEY + ":" + responseKey;
		params.put("_cmd", res);
		
		//Send response to recipient
		mainExtension.sendResponse(params, -1, null, recipients);
	}
	
	@SuppressWarnings("unchecked")
	private LinkedList getUsersChannels(LinkedList<String> userNames, String excludeName)
	{
		LinkedList ll = new LinkedList();
		
		// Retrieve users channels
		synchronized (userNames)
		{
			for (String userName : userNames)
			{
				if (userName != null && !userName.equals(excludeName))
				{
					User user = mainExtension.getCurrentZone().getUserByName(userName);
					
					if (user != null)
						ll.add(user.getChannel());
				}
			}
		}
		
		return ll;
	}
}
package com.smartfoxserver.redbox.managers;

import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;
import org.json.JSONObject;

/**
 * Inteface for RedBox's internal managers.
 * 
 * @version	1.0.0
 * 
 * @author	The gotoAndPlay() Team
 * 			http://www.smartfoxserver.com
 * 			http://www.gotoandplay.it
 */
public interface IRequestHandler
{
	public void handleRequest(String cmd, JSONObject data, User fromUser) throws Exception;
	
	public void handleInternalEvent(InternalEventObject evt) throws Exception;
}

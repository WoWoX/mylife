package com.smartfoxserver.redbox.utils;

import it.gotoandplay.smartfoxserver.SmartFoxServer;

/**
 * RedBox logger.
 * Infos are logged only if {@link #enableLogging} is set to true; warnings are always logged.
 * 
 * @version	1.0.0
 * 
 * @author	The gotoAndPlay() Team
 * 			http://www.smartfoxserver.com
 * 			http://www.gotoandplay.it
 */
public class Logger
{
	public static boolean enableLogging = false;
	
	public static void logInfo(String info)
	{
		if (enableLogging)
			SmartFoxServer.log.info("[RedBox] " + info);
	}
	
	public static void logWarning(String warn)
	{
		SmartFoxServer.log.warning("[RedBox] " + warn);
	}
}

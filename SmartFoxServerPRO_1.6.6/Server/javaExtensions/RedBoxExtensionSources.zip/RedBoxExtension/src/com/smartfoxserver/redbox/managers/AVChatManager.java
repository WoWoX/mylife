package com.smartfoxserver.redbox.managers;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.concurrent.ConcurrentHashMap;

import it.gotoandplay.smartfoxserver.data.User;
import it.gotoandplay.smartfoxserver.events.InternalEventObject;

import org.json.JSONException;
import org.json.JSONObject;

import com.smartfoxserver.redbox.RedBoxExtension;
import com.smartfoxserver.redbox.data.ChatSession;
import com.smartfoxserver.redbox.utils.Constants;
import com.smartfoxserver.redbox.utils.Logger;

/**
 * SmartFoxServer's RedBox Audio/Video Chat Manager.
 * This class is responsible for audio/video chat sessions handling.
 * 
 * @version	1.0.0
 * 
 * @author	The gotoAndPlay() Team
 * 			http://www.smartfoxserver.com
 * 			http://www.gotoandplay.it
 */
public class AVChatManager implements IRequestHandler
{
	//--------------------------------------
	// CLASS CONSTANTS
	//--------------------------------------
	
	private static final String TIMESTAMP_FORMAT = "yyyyMMddHHmmssSSS";
	
	// Request type
	private static final String REQ_TYPE_SEND = "send";				// Stream from requester to recipient
	private static final String REQ_TYPE_RECEIVE = "receive";		// Stream from recipient to requester
	private static final String REQ_TYPE_SEND_RECEIVE = "send&rcv";	// Bi-diretional stream
	
	// Incoming commands
	private static final String CMD_REQUEST = "req";
	private static final String CMD_ACCEPT = "accept";
	private static final String CMD_REFUSE = "refuse";
	private static final String CMD_STOP = "stop";
	
	// Outgoing responses
	private static final String RES_REQUEST = "req";
	private static final String RES_START = "start";
	private static final String RES_REFUSED = "refused";
	private static final String RES_STOP = "stop";
	
	// Outgoing errors
	private static final String ERR_NO_RECIPIENT = "err_noRcp";
	private static final String ERR_DUPLICATE_REQUEST = "err_dup";
	
	//--------------------------------------
	//  PRIVATE VARIABLES
	//--------------------------------------
	
	private RedBoxExtension mainExtension;
	private ConcurrentHashMap<String, ChatSession> chatSessions;
	
	//-------------------------------------------------------
	// CONSTRUCTOR
	//-------------------------------------------------------
	
	/**
	 * The AVChatManager contructor.
	 */
	public AVChatManager(RedBoxExtension ext)
	{
		// Initialize AVClipManager
		mainExtension = ext;
		chatSessions = new ConcurrentHashMap<String, ChatSession>();
		
		Logger.logInfo("RedBox's AVChatManager initialized");
	}

	//-------------------------------------------------------
	// PUBLIC METHODS
	//-------------------------------------------------------
	
	/**
	 * Handle client requests.
	 */
	public void handleRequest(String cmd, JSONObject data, User fromUser) throws Exception
	{
		// New chat request sent
		if (cmd.equals(CMD_REQUEST))
			handleChatRequest(fromUser, data);
		
		// Chat request refused
		else if (cmd.equals(CMD_REFUSE))
			handleChatRefused(fromUser, data);
		
		// Chat request accepted
		else if (cmd.equals(CMD_ACCEPT))
			handleChatAccepted(fromUser, data);
		
		// Chat stopped
		else if (cmd.equals(CMD_STOP))
			handleChatStopped(fromUser, data);
	}
	
	/**
	 * Handle internal events.
	 */
	public void handleInternalEvent(InternalEventObject evt) throws Exception
	{
		String evtName = evt.getEventName();
		
		// User disconnected or logged out
		if (evtName.equals(InternalEventObject.EVENT_USER_LOST) || evtName.equals(InternalEventObject.EVENT_LOGOUT))
			handleRemoveUserRequest((User) evt.getObject("user"));
	}
	
	//-------------------------------------------------------
	// PRIVATE METHODS
	//-------------------------------------------------------
	
	// Request handlers -------------------------------------
	
	/**
	 * Validate request and forward to recipient.
	 */
	private void handleChatRequest(User requester, JSONObject requestData)
	{
		try
		{
			int requesterId = requester.getUserId();
			String requesterName = requester.getName();
			
			int recipientId = requestData.getInt("uId");
			
			String requestId = requestData.getString("id");
			String requestType = requestData.getString("type");
			boolean enableCamera = requestData.getBoolean("cam");
			boolean enableMicrophone = requestData.getBoolean("mic");
			
			Logger.logInfo("A/v chat request of type '" + requestType + "' sent by user " + requesterName + " to user id " + recipientId);
			
			// Validate request type
			boolean validType = (requestType.equals(REQ_TYPE_SEND) || requestType.equals(REQ_TYPE_RECEIVE) || requestType.equals(REQ_TYPE_SEND_RECEIVE));
			
			if (validType)
			{
				// Validate request id
				String validId = requestType + "-" + String.valueOf(requesterId) + "-" + String.valueOf(recipientId);
				
				if (requestId.equals(validId))
				{
					// Validate request
					boolean validRequest = true;
					
					// Check if the same request has already been submitted
					if (chatSessions.get(requestId) != null)
					{
						validRequest = false;
						Logger.logInfo("Request already sent before by the same requester: request discarded");
					}
					
					// Check if a mutual request has already been submitted
					String mutualReqId = "";
					
					if (requestType.equals(REQ_TYPE_SEND_RECEIVE))
					{
						// Mutual request has same type but inverse requester/recipient
						mutualReqId = requestType + "-" + String.valueOf(recipientId) + "-" + String.valueOf(requesterId);
					}
					else if (requestType.equals(REQ_TYPE_SEND))
					{
						// Mutual request has "RECEIVE" type and inverse requester/recipient
						mutualReqId = REQ_TYPE_RECEIVE + "-" + String.valueOf(recipientId) + "-" + String.valueOf(requesterId);
					}
					else if (requestType.equals(REQ_TYPE_RECEIVE))
					{
						// Mutual request has "SEND" type and inverse requester/recipient
						mutualReqId = REQ_TYPE_SEND + "-" + String.valueOf(recipientId) + "-" + String.valueOf(requesterId);
					}
					
					if (chatSessions.get(mutualReqId) != null)
					{
						validRequest = false;
						Logger.logInfo("Mutual request already sent before by the recipient: request discarded");
					}
					
					if (validRequest)
					{
						// Check if recipient is still available: if yes, send request to recipient; if no, send error to requester
						User recipient = mainExtension.getUserById(recipientId);
						
						if (recipient != null)
						{
							// Create a new session
							ChatSession session = new ChatSession();
							session.id = requestId;
							session.type = requestType;
							session.pending = true;
							session.requesterId = requesterId;
							session.requesterName = requesterName;
							session.recipientId = recipientId;
							session.recipientName = recipient.getName();
							session.enableCam = enableCamera;
							session.enableMic = enableMicrophone;
							
							// Add to sessions manager
							chatSessions.put(session.id, session);
							
							// Send request to recipient
							net.sf.json.JSONObject params = new net.sf.json.JSONObject();
							params.put("id", session.id);
							params.put("type", session.type);
							params.put("uId", session.requesterId);
							params.put("uName", session.requesterName);
							params.put("cam", session.enableCam);
							params.put("mic", session.enableMic);
							
							sendResponse(mainExtension.getUserChannel(recipient), RES_REQUEST, params);
							
							Logger.logInfo("Request sent to recipient; session id: " + session.id);
						}
						else
						{
							// Send "no recipient" error to requester
							net.sf.json.JSONObject params = new net.sf.json.JSONObject();
							params.put("id", requestId);
							
							sendResponse(mainExtension.getUserChannel(requester), ERR_NO_RECIPIENT, params);
							
							Logger.logInfo("Recipient not available: error sent to requester");
						}
					}
					else
					{
						// Send "duplicate request" error to requester
						net.sf.json.JSONObject params = new net.sf.json.JSONObject();
						params.put("id", requestId);
						
						sendResponse(mainExtension.getUserChannel(requester), ERR_DUPLICATE_REQUEST, params);
						
						Logger.logInfo("Duplicate request error sent to requester");
					}
				}
				else
					Logger.logWarning("Invalid a/v chat request id: '" + requestId + "'; request discarded");
			}
			else
				Logger.logWarning("Invalid a/v chat request type: '" + requestType + "'; request discarded");
		}
		catch (JSONException e)
		{
			Logger.logWarning("JSON exception in handleChatRequest method: " + e.getMessage());
		}
	}
	
	/**
	 * Handle refusal and forward to requester.
	 */
	private void handleChatRefused(User recipient, JSONObject responseData)
	{
		try
		{
			String sessionId = responseData.getString("id");
			
			Logger.logInfo("A/v chat request '" + sessionId + "' refused by user " + recipient.getName() + " (" + recipient.getUserId() + ")");
			
			// Retrieve session
			ChatSession session = chatSessions.get(sessionId);
			
			// Check if session still exists
			if (session != null && session.pending)
			{
				// Check if requester is still available
				User requester = mainExtension.getUserById(session.requesterId);
				
				if (requester != null)
				{
					// Send "connection refused" event to requester
					net.sf.json.JSONObject params = new net.sf.json.JSONObject();
					params.put("id", session.id);
					params.put("uName", session.recipientName);
					
					sendResponse(mainExtension.getUserChannel(requester), RES_REFUSED, params);
				}
			
				// Remove session
				chatSessions.remove(sessionId);
			}
		}
		catch (JSONException e)
		{
			Logger.logWarning("JSON exception in handleChatRefused method: " + e.getMessage());
		}
	}
	
	/**
	 * Handle acceptance: start chat on both clients.
	 */
	private void handleChatAccepted(User recipient, JSONObject responseData)
	{
		try
		{
			String sessionId = responseData.getString("id");
			
			Logger.logInfo("A/v chat request '" + sessionId + "' accepted by user " + recipient.getName() + " (" + recipient.getUserId() + ")");
			
			// Retrieve session
			ChatSession session = chatSessions.get(sessionId);
			
			// Check if session still exists
			if (session != null && session.pending)
			{
				// Check if requester is still available
				User requester = mainExtension.getUserById(session.requesterId);
				
				if (requester != null)
				{
					String zone = mainExtension.getOwnerZone();
					SimpleDateFormat dateFormatter = new SimpleDateFormat(TIMESTAMP_FORMAT);
					String timeStamp = dateFormatter.format(new Date());
					
					// Generate requester's stream id
					String requesterStreamId = null;
					if (session.type.equals(REQ_TYPE_SEND) || session.type.equals(REQ_TYPE_SEND_RECEIVE))
						requesterStreamId = zone + "_" + timeStamp + "_" + requester.getUserId();
					
					// Generate recipient's stream id
					String recipientStreamId = null;
					if (session.type.equals(REQ_TYPE_RECEIVE) || session.type.equals(REQ_TYPE_SEND_RECEIVE))
						recipientStreamId = zone + "_" + timeStamp + "_" + recipient.getUserId();
					
					// Update chat session data
					session.pending = false;
					session.requesterStreamId = requesterStreamId;
					session.recipientStreamId = recipientStreamId;
					
					// Send "start chat" event to both requester and recipient
					sendStartChatResponse(session.id, requester, requesterStreamId, recipient.getName(), recipientStreamId);
					sendStartChatResponse(session.id, recipient, recipientStreamId, requester.getName(), requesterStreamId);
				}
			}
		}
		catch (JSONException e)
		{
			Logger.logWarning("JSON exception in handleChatRefused method: " + e.getMessage());
		}
	}
	
	/**
	 * Handle chat stop.
	 */
	private void handleChatStopped(User sender, JSONObject responseData)
	{
		try
		{
			String sessionId = responseData.getString("id");
			
			Logger.logInfo("A/v chat request '" + sessionId + "' stopped by user " + sender.getName() + " (" + sender.getUserId() + ")");
			
			// Retrieve session
			ChatSession session = chatSessions.get(sessionId);
			
			// Check if session still exists
			if (session != null)
			{
				// Check if mate is still available
				int toUserId = (sender.getUserId() == session.requesterId ? session.recipientId : session.requesterId);
				User toUser = mainExtension.getUserById(toUserId);
				
				if (toUser != null)
				{
					// Send "stop chat" event to mate
					sendStopChatResponse(toUser, session);
					
					// Remove session
					chatSessions.remove(session.id);
				}
			}
		}
		catch (JSONException e)
		{
			Logger.logWarning("JSON exception in handleChatRefused method: " + e.getMessage());
		}
	}
	
	/**
	 * Stop all session in which user is involved.
	 */
	private void handleRemoveUserRequest(User user)
	{
		for (ChatSession session : chatSessions.values())
		{
			// Check if user is involved in session
			if (session.requesterId == user.getUserId() || session.recipientId == user.getUserId())
			{
				
				JSONObject obj = new JSONObject();
				
				try
				{
					obj.put("id", session.id);
				}
				catch (JSONException e)
				{
					Logger.logWarning("JSON exception in handleRemoveUserRequest method: " + e.getMessage());
					obj = null;
				}
				
				if (obj != null)
				{
					// Simulate external stop command
					handleChatStopped(user, obj);
				}
			}
		}
	}
	
	// Other private methods --------------------------------
	
	/**
	 * Send response to client/s.
	 */
	private void sendResponse(LinkedList recipients, String responseKey, net.sf.json.JSONObject params)
	{
		if (params == null)
			params = new net.sf.json.JSONObject();
		
		// Build response name and add to params
		String res = Constants.EXTENSION_KEY + ":" + Constants.AV_CHAT_MANAGER_KEY + ":" + responseKey;
		params.put("_cmd", res);
		
		//Send response to recipient
		mainExtension.sendResponse(params, -1, null, recipients);
	}
	
	/**
	 * Send "start chat" response to clients.
	 */
	private void sendStartChatResponse(String sessionId, User user, String userStream, String mateName, String mateStream)
	{
		net.sf.json.JSONObject params = new net.sf.json.JSONObject();
		params.put("id", sessionId);
		params.put("mName", mateName);
		
		if (userStream != null)
			params.put("stream", userStream);
		
		if (mateStream != null)
			params.put("mStream", mateStream);
		
		sendResponse(mainExtension.getUserChannel(user), RES_START, params);
	}
	
	/**
	 * Send "stop chat" response to client.
	 */
	private void sendStopChatResponse(User toUser, ChatSession session)
	{
		net.sf.json.JSONObject params = new net.sf.json.JSONObject();
		params.put("id", session.id);
		
		// We add the mate name to the response in case the session was stopped by the recipient just after he received the request,
		// but before he was able to accept it (due to disconnection for example)
		String mateName = (toUser.getUserId() == session.requesterId ? session.recipientName : session.requesterName);
		params.put("mName", mateName);
		
		sendResponse(mainExtension.getUserChannel(toUser), RES_STOP, params);
	}
}

package com.smartfoxserver.redbox.data;

import java.util.Properties;

public class Clip
{
	public String id;
	public String filename;
	public String username;
	private Properties properties;
	private Long size;
	private String lastModified;
	//private String type;
	
	
	public Properties getProperties()
	{
		return properties;
	}

	public void setProperties(Properties properties)
	{
		this.properties = properties;
	}
	
	public String getLastModified()
	{
		return lastModified;
	}

	public void setLastModified(String lastModified)
	{
		this.lastModified = lastModified;
	}

	public Long getSize()
	{
		return size;
	}

	public void setSize(Long size)
	{
		this.size = size;
	}
	/*
	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}
	 */
	public Clip()
	{
		
	}
}
